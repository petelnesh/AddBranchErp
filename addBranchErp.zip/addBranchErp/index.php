<!DOCTYPE html>
<html lang="en">
  <head>
    <title>ERP</title>

    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/font-awesome.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="bootstrap/js/jquery-1.11.1.min.js"></script>
	<style>
  ul#stepForm, ul#stepForm li {
    margin: 0;
    padding: 0;
  }
  ul#stepForm li {
    list-style: none outside none;
  } 
  label{margin-top: 10px;}
  .help-inline-error{color:red;}
</style>
  </head>
  <body>
  
  <br />
  <br />
  <br />
    <div class="container">
      <div class="page-header">
        <h1>Register New Customer</h1>
      </div>
      <div class="clearfix"></div>
<div class="container" style="padding-left: 0px; padding-right: 15px;">
  <div class="panel panel-success">
    <div class="panel-heading">
      <h3 class="panel-title">Complete this form in 3 steps!</h3>
    </div>
    <div class="panel-body">
      <form name="basicform" id="basicform" method="post" action="index.php" enctype="multipart/form-data">
        
        <div id="sf1" class="frm">
          <fieldset>
            <legend>Step 1 of 3</legend>
            <div class="row">
            <div class="col-lg-5" style="margin-left: 30px;">
            	<div class="form-group">
              <label class="control-label" for="branchcode">Branch Code: </label>
                <input type="text" placeholder="Your Branch Code" id="branchcode" name="branchcode" class="form-control" autocomplete="off">
              
            </div>
			<div class="clearfix" style="height: 10px;clear: both;"></div>
			 <div class="form-group">
              <label  control-label" for="deptor_name">Debtor number: </label>
             
                <input type="text" placeholder="Enter Deptor number" id="deptor_name" name="deptor_name" class="form-control" autocomplete="off">
             
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>
	
			<div class="form-group">
              <label class="control-label" for="uname">Branch Name:</label>
             
                <input type="text" placeholder="Enter Branch Name" id="uname" name="branchname" class="form-control" autocomplete="off">
             
            </div>
            <div class="form-group">
              <label class="control-label" for="braddone">Branch Address 1</label>
             
                <input type="text" placeholder="Enter Branch address one" id="braddone" name="braddone" class="form-control" autocomplete="off">
             
            </div>
            <div class="form-group">
              <label class="control-label" for="braddtwo">Branch Address 2</label>
             
                <input type="text" placeholder="Enter Branch address two" id="braddtwo" name="braddtwo" class="form-control" autocomplete="off">
             
            </div>
            <div class="form-group">
              <label class="control-label" for="braddthree">Branch Address 3</label>
             
                <input type="text" placeholder="Enter Branch Address three" id="braddthree" name="braddthree" class="form-control" autocomplete="off">
             
            </div>
            </div>
            <div class="col-lg-5" style="margin-left: 30px;">
            	<div class="form-group">
              <label class="control-label" for="braddfour">Branch Address 4: </label>
                <input type="text" placeholder="Your Branch Address four" id="braddfour" name="braddfour" class="form-control" autocomplete="off">
              
            </div>
			 <div class="form-group">
              <label  control-label" for="braddfive">Branch Address 5: </label>
             
                <input type="text" placeholder="Enter Branch address five " id="braddfive" name="braddfive" class="form-control" autocomplete="off">
             
            </div>
            
	
			<div class="form-group">
              <label class="control-label" for="braddsix">Branch Address 6:</label>
             
                <input type="text" placeholder="Enter Branch Address six" id="uname" name="braddsix" class="form-control" autocomplete="off">
             
            </div>


            <div class="form-group">
              <label class="control-label" for="braddlat">Latitude:</label>
             
                <input type="text" placeholder="Enter Latitude" id="braddlat" name="braddlat" class="form-control" autocomplete="off">
             
            </div>

            <div class="form-group">
              <label class="control-label" for="braddlng">Longitude:</label>
             
                <input type="text" placeholder="Enter Longitude" id="braddlng" name="braddlng" class="form-control" autocomplete="off">
             
            </div>
            <div class="form-group">
              <label class="control-label" for="braddest">Estimated Delivery Day:</label>
             
                <input type="text" placeholder="Enter Estimated Delivery Day" id="braddest" name="braddest" class="form-control" autocomplete="off">
             
            </div>
            </div>
            </div>

      
            <div class="form-group">
              <div class="col-lg-10 col-lg-offset-2">
                <button class="btn btn-success open1" type="button">Next<span class="fa fa-arrow-right"></span></button> 
              </div>
            </div>

          </fieldset>
        </div>

        <div id="sf2" class="frm" style="display: none;">
          <fieldset>
            <legend>Step 2 of 3</legend>
            
           <div class="row">
            <div class="col-lg-5" style="margin-left: 30px;">
            	<div class="form-group">
              <label class="control-label" for="area">Area: </label>
                <input type="text" placeholder="Enter Area" id="area" name="area" class="form-control" autocomplete="off">
              
            </div>
			 <div class="form-group">
              <label  control-label" for="salesman">Salesman: </label>
             
                <input type="text" placeholder="Enter Salesman" id="salesman" name="salesman" class="form-control" autocomplete="off">
             
            </div>
	
			<div class="form-group">
              <label class="control-label" for="forwarddate">Forward date:</label>
             
                <input type="text" placeholder="Enter Forward date" id="forwarddate" name="forwarddate" class="form-control" autocomplete="off">
             
            </div>
            <div class="form-group">
              <label class="control-label" for="uname">Phone Number</label>
             
                <input type="text" placeholder="Enter Your Mobile Number" id="uname" name="number" class="form-control" autocomplete="off">
             
            </div>
            <div class="form-group">
              <label class="control-label" for="uname">Fax Number</label>
             
                <input type="text" placeholder="Enter Your Mobile Number" id="uname" name="faxnumber" class="form-control" autocomplete="off">
             
            </div>
            </div>
            <div class="col-lg-5" style="margin-left: 30px;">
            	<div class="form-group">
              <label class="control-label" for="contname">Contact Name</label>
             
                <input type="text" placeholder="Enter Contact" id="contname" name="contname" class="form-control" autocomplete="off">
             
            </div>
            	<div class="form-group">
              <label class="control-label" for="email">Email</label>
                <input type="email" placeholder="Your Email" id="email" name="email" class="form-control" autocomplete="off">
              
            </div>
			 <div class="form-group">
              <label  control-label" for="location">Default Location</label>
             
                <input type="text" placeholder="User Location" id="location" name="location" class="form-control" autocomplete="off">
             
            </div>
	
			<div class="form-group">
              <label class="control-label" for="taxgrid">Tax group Id:</label>
             
                <input type="text" placeholder="Enter Tax group Id" id="taxgrid" name="taxgrid" class="form-control" autocomplete="off">
             
            </div>


            <div class="form-group">
              <label class="control-label" for="shivia">Default Shivia:</label>
             
                <input type="text" placeholder="Enter Default Shivia" id="shivia" name="shivia" class="form-control" autocomplete="off">
             
            </div>
          </div>
         

            <div class="form-group">
              <div class="col-lg-10 col-lg-offset-2">
                <button class="btn btn-warning back2" type="button"><span class="fa fa-arrow-left"></span> Back</button> 
                <button class="btn btn-success open2" type="button">Next <span class="fa fa-arrow-right"></span></button> 
              </div>
            </div>

          </fieldset>
        </div>

        <div id="sf3" class="frm" style="display: none;">
          <fieldset>
            <legend>Step 3 of 3</legend>

            <div class="row">
            <div class="col-lg-5" style="margin-left: 30px;">
            		<div class="form-group">
              <label class="control-label" for="blind">Deliver Blind: </label>
              
                <input type="text" placeholder="Your Deliver blind" id="blind" name="blind" class="form-control" autocomplete="off">
             
            </div>
            	<div class="form-group">
              <label class="control-label" for="delivertrans">Disable Transaction: </label>
              
                <input type="text" placeholder="Your Disable Transaction" id="delivertrans" name="delivertrans" class="form-control" autocomplete="off">
             
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>

            <div class="form-group">
              <label class="control-label" for="postbranchone">Branch Post Address 1: </label>
             
                <input type="text" placeholder="Enter Branch Post Address one" id="postbranchone" name="postbranchone" class="form-control" autocomplete="off">
              
            </div>
            <div class="form-group">
              <label class="control-label" for="postbranchtwo">Branch Post Address 2: </label>
              
                <input type="text" placeholder="Enter Branch Post Address two" id="postbranchtwo" name="postbranchtwo" class="form-control" autocomplete="off">
             
            </div>

            <div class="form-group">
              <label class="control-label" for="upass1">Branch Post Address 2: </label>
             
                <input type="text" placeholder="Enter Branch Post Address 2" id="upass2" name="postbranchthree" class="form-control" autocomplete="off">
              
            </div>

            </div > 
            <div class="col-lg-5" style="margin-left: 30px;">
            	<div class="form-group">
              <label class="control-label" for="postbranchthree">Branch Post Address 3: </label>
              
                <input type="text" placeholder="Enter Branch Post Address 3:" id="postbranchthree" name="postbranchthree" class="form-control" autocomplete="off">
             
            </div>
            	<div class="form-group">
              <label class="control-label" for="postbranchfour">Branch Post Address 4: </label>
              
                <input type="text" placeholder="Enter Branch Post Address 4:" id="postbranchfour" name="postbranchfour" class="form-control" autocomplete="off">
             
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>

            <div class="form-group">
              <label class="control-label" for="postbranchfive">Branch Post Address 5: </label>
             
                <input type="Text" placeholder="Enter Branch Post Address 5" id="postbranchfive" name="postbranchfive" class="form-control" autocomplete="off">
              
            </div>
            <div class="form-group">
              <label class="control-label" for="postbranchsix">Branch Post Address 6: </label>
              
                <input type="text" placeholder="Enter Branch Post Address 6" id="postbranchsix" name="postbranchsix" class="form-control" autocomplete="off">
             
            </div>
           

            <div class="form-group">
              <label class="control-label" for="postbranchinst">Special Instructions: </label>
             
                <input type="text" placeholder="Enter Special Instructions" id="postbranchinst" name="postbranchinst" class="form-control" autocomplete="off">
              
            </div>
            <div class="form-group">
              <label class="control-label" for="postbranchcode">Customer branch code: </label>
             
                <input type="text" placeholder="Enter Customer branch code" id="postbranchcode" name="postbranchcode" class="form-control" autocomplete="off">
              
            </div>
            </div >
            </div>

            <div class="form-group">
              <div class="col-lg-10 col-lg-offset-2">
                <button class="btn btn-warning back3" type="button"><span class="fa fa-arrow-left"></span> Back</button> 
                <button class="btn btn-success" type="submit" name="submit">Submit </button> 
                <img src="images/spinner.gif" alt="" id="loader" style="display: none">
              </div>
            </div>

          </fieldset>
        </div>
      </form>
    </div>
  </div>


</div>
<?php 
include ("post.php");
?>
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script type="text/javascript">
  
  jQuery().ready(function() {

    // validate form on keyup and submit
    var v = jQuery("#basicform").validate({
      rules: {
		    branchcode: {
          required: true,
          minlength: 2,
          maxlength: 16
        },
        debtor_name: {
          required: true,
          minlength: 2,
          maxlength: 16
        },
        branchname: {
          required: true,
          minlength: 2,
          maxlength: 100,
        },
       area: {
          required: true,
          minlength: 6,
          maxlength: 15,
        },
       

      },
      errorElement: "span",
      errorClass: "help-inline-error",
    });

    $(".open1").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf2").show("slow");
      }
    });

    $(".open2").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf3").show("slow");
      }
    });
    
    $(".open3").click(function() {
      if (v.form()) {
        $("#loader").show();
         setTimeout(function(){
           $("#basicform").html('<h2>Thanks for your time.</h2>');
         }, 1000);
        return false;
      }
    });
    
    $(".back2").click(function() {
      $(".frm").hide("fast");
      $("#sf1").show("slow");
    });

    $(".back3").click(function() {
      $(".frm").hide("fast");
      $("#sf2").show("slow");
    });

  });
</script>

<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
