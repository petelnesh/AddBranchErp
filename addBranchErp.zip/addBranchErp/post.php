<?php 

include("includes/db.php");
if(isset($_POST['submit'])){


	$branchcode = $_POST['branchcode'];
	$deptor_name = $_POST['deptor_name'];
	$branchname = $_POST['branchname'];
	$braddone = $_POST['braddone'];
	$braddtwo = $_POST['braddtwo'];
	$braddthree = $_POST['braddthree'];
	$braddfour = $_POST['braddfour'];

	$braddfive = $_POST['braddfive'];
	$braddsix = $_POST['braddsix'];
	$braddlat = $_POST['braddlat'];
	$braddlng = $_POST['braddlng'];
	$braddest = $_POST['braddest'];

	$area = $_POST['area'];
	$salesman = $_POST['salesman'];
	$forwarddate = $_POST['forwarddate'];
	$number = $_POST['number'];
	$faxnumber = $_POST['faxnumber'];
	$contactname=$_POST['contname'];
	$email = $_POST['email'];
	$location = $_POST['location'];

	$taxgrid = $_POST['taxgrid'];
	$shivia = $_POST['shivia'];
	$blind = $_POST['blind'];
	$delivertrans = $_POST['delivertrans'];
	$postbranchone = $_POST['postbranchone'];
	$postbranchtwo = $_POST['postbranchtwo'];

	$postbranchthree = $_POST['postbranchthree'];
	$postbranchfour = $_POST['postbranchfour'];
	$postbranchfive = $_POST['postbranchfive'];
	$postbranchsix = $_POST['postbranchsix'];
	$postbranchinst = $_POST['postbranchinst'];
	$postbranchcode = $_POST['postbranchcode'];
	
	
	
	$query= "insert into custbranch(branchcode,debtorno,brname,braddress1,braddress2,braddress3,braddress4,braddress5,braddress6,lat,lng,estdeliverydays,area,salesman,fwddate,phoneno,faxno,contactname,email,defaultlocation,taxgroupid,defaultshipvia,deliverblind,disabletrans,brpostaddr1,brpostaddr2,brpostaddr3,brpostaddr4,brpostaddr5,brpostaddr6,specialinstructions,custbranchcode) 
			values('$branchcode','$deptor_name','$branchname','$braddone','$braddtwo','$braddthree','$braddfour','$braddfive','$braddsix','$braddlat','$braddlng','$braddest','$area','$salesman','$forwarddate','$number','$faxnumber','$contactname','$email','$location','$taxgrid','$shivia','$blind','$delivertrans','$postbranchone','$postbranchtwo','$postbranchthree','$postbranchfour','$postbranchfive','$postbranchsix','$postbranchinst','$postbranchcode')";
	
	if(mysql_query($query)){
	
	echo "<h1 class='center'>Done</h1>";
	
	}}
?>